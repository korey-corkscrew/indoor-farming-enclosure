#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes

// Proximity sensors
#define ULTRASONIC_CONTROL_0    GPIO_PIN_RA7
#define ULTRASONIC_ECHO_0       GPIO_PIN_RB14
#define ULTRASONIC_CONTROL_1    GPIO_PIN_RD5
#define ULTRASONIC_ECHO_1       GPIO_PIN_RD8

// Motor control
#define MOTOR_CONTROL_EN        GPIO_PIN_RB9

// I2C mux channel select
#define I2C_MUX_A0              GPIO_PIN_RE1
#define I2C_MUX_A1              GPIO_PIN_RA14

// Temperature sensors
typedef enum {
  TEMP_HUM_SENSOR_0,
  TEMP_HUM_SENSOR_1
} TempertaureHumiditySensor;

// Luminosity sensors
typedef enum {
  LUM_SENSOR_0,
  LUM_SENSOR_1
} LuminositySensor;

// Proximity sensors
typedef enum {
  PROXIMITY_SENSOR_LEFT,
  PROXIMITY_SENSOR_RIGHT
} ProximitySensor;

// Motors
typedef enum {
  MOTOR_LEFT,
  MOTOR_RIGHT
} Motor;

// Directions
typedef enum {
  UP,
  DOWN
} Direction;

// Relays
typedef enum {
  HEATER = GPIO_PIN_RA10,
  FAN_IN = GPIO_PIN_RB13,
  FAN_OUT = GPIO_PIN_RB12,
  HUMIDIFIER = GPIO_PIN_RB11,
  LIGHTS = GPIO_PIN_RB10,
  RELAY_5 = GPIO_PIN_RF1,
  RELAY_6 = GPIO_PIN_RF0,
  RELAY_7 = GPIO_PIN_RD6
} Relay;

typedef enum {
  ON = true,
  OFF = false
} State;

// Desired conditions
uint8_t desiredTemperature;
uint8_t desiredHumidity;
uint16_t desiredLuminosity;


// -----------------------------------------------------------------------------
// ADAFRUIT Si7021 Humidity / Temperature Sensor
// -----------------------------------------------------------------------------
#define SI7021_DEFAULT_ADDRESS 0x40

#define SI7021_MEASRH_HOLD_CMD                                                 \
  0xE5 /**< Measure Relative Humidity, Hold Master Mode */
#define SI7021_MEASRH_NOHOLD_CMD                                               \
  0xF5 /**< Measure Relative Humidity, No Hold Master Mode */
#define SI7021_MEASTEMP_HOLD_CMD                                               \
  0xE3 /**< Measure Temperature, Hold Master Mode */
#define SI7021_MEASTEMP_NOHOLD_CMD                                             \
  0xF3 /**< Measure Temperature, No Hold Master Mode */
#define SI7021_READPREVTEMP_CMD                                                \
  0xE0 /**< Read Temperature Value from Previous RH Measurement */
#define SI7021_RESET_CMD 0xFE           /**< Reset Command */
#define SI7021_WRITERHT_REG_CMD 0xE6    /**< Write RH/T User Register 1 */
#define SI7021_READRHT_REG_CMD 0xE7     /**< Read RH/T User Register 1 */
#define SI7021_WRITEHEATER_REG_CMD 0x51 /**< Write Heater Control Register */
#define SI7021_READHEATER_REG_CMD 0x11  /**< Read Heater Control Register */
#define SI7021_REG_HTRE_BIT 0x02        /**< Control Register Heater Bit */
#define SI7021_ID1_CMD 0xFA0F           /**< Read Electronic ID 1st Byte */
#define SI7021_ID2_CMD 0xFCC9           /**< Read Electronic ID 2nd Byte */
#define SI7021_FIRMVERS_CMD 0x84B8      /**< Read Firmware Revision */

#define SI7021_REV_1 0xff /**< Sensor revision 1 */
#define SI7021_REV_2 0x20 /**< Sensor revision 2 */

/** An enum to represent sensor types **/
enum si_sensorType {
  SI_Engineering_Samples,
  SI_7013,
  SI_7020,
  SI_7021,
  SI_UNKNOWN,
};

/** An enum to represent the sensor heater heat levels **/
enum si_heatLevel {
  SI_HEATLEVEL_LOWEST = 0x00,
  SI_HEATLEVEL_LOW = 0x01,
  SI_HEATLEVEL_MEDIUM = 0x02,
  SI_HEATLEVEL_HIGH = 0x04,
  SI_HEATLEVEL_HIGHER = 0x08,
  SI_HEATLEVEL_HIGHEST = 0x0F,
};


// -----------------------------------------------------------------------------
// ADAFRUIT TSL2591 Luminosity Sensor
// -----------------------------------------------------------------------------
#define TSL2591_ADDR (0x29) ///< Default I2C address

#define TSL2591_COMMAND_BIT                                                    \
  (0xA0) ///< 1010 0000: bits 7 and 5 for 'command normal'

///! Special Function Command for "Clear ALS and no persist ALS interrupt"
#define TSL2591_CLEAR_INT (0xE7)
///! Special Function Command for "Interrupt set - forces an interrupt"
#define TSL2591_TEST_INT (0xE4)

#define TSL2591_WORD_BIT (0x20)  ///< 1 = read/write word (rather than byte)
#define TSL2591_BLOCK_BIT (0x10) ///< 1 = using block read/write

#define TSL2591_ENABLE_POWEROFF (0x00) ///< Flag for ENABLE register to disable
#define TSL2591_ENABLE_POWERON (0x01)  ///< Flag for ENABLE register to enable
#define TSL2591_ENABLE_AEN                                                     \
  (0x02) ///< ALS Enable. This field activates ALS function. Writing a one
         ///< activates the ALS. Writing a zero disables the ALS.
#define TSL2591_ENABLE_AIEN                                                    \
  (0x10) ///< ALS Interrupt Enable. When asserted permits ALS interrupts to be
         ///< generated, subject to the persist filter.
#define TSL2591_ENABLE_NPIEN                                                   \
  (0x80) ///< No Persist Interrupt Enable. When asserted NP Threshold conditions
         ///< will generate an interrupt, bypassing the persist filter

#define TSL2591_LUX_DF (408.0F)   ///< Lux cooefficient
#define TSL2591_LUX_COEFB (1.64F) ///< CH0 coefficient
#define TSL2591_LUX_COEFC (0.59F) ///< CH1 coefficient A
#define TSL2591_LUX_COEFD (0.86F) ///< CH2 coefficient B

/// TSL2591 Register map
enum {
  TSL2591_REGISTER_ENABLE = 0x00,          // Enable register
  TSL2591_REGISTER_CONTROL = 0x01,         // Control register
  TSL2591_REGISTER_THRESHOLD_AILTL = 0x04, // ALS low threshold lower byte
  TSL2591_REGISTER_THRESHOLD_AILTH = 0x05, // ALS low threshold upper byte
  TSL2591_REGISTER_THRESHOLD_AIHTL = 0x06, // ALS high threshold lower byte
  TSL2591_REGISTER_THRESHOLD_AIHTH = 0x07, // ALS high threshold upper byte
  TSL2591_REGISTER_THRESHOLD_NPAILTL =
      0x08, // No Persist ALS low threshold lower byte
  TSL2591_REGISTER_THRESHOLD_NPAILTH =
      0x09, // No Persist ALS low threshold higher byte
  TSL2591_REGISTER_THRESHOLD_NPAIHTL =
      0x0A, // No Persist ALS high threshold lower byte
  TSL2591_REGISTER_THRESHOLD_NPAIHTH =
      0x0B, // No Persist ALS high threshold higher byte
  TSL2591_REGISTER_PERSIST_FILTER = 0x0C, // Interrupt persistence filter
  TSL2591_REGISTER_PACKAGE_PID = 0x11,    // Package Identification
  TSL2591_REGISTER_DEVICE_ID = 0x12,      // Device Identification
  TSL2591_REGISTER_DEVICE_STATUS = 0x13,  // Internal Status
  TSL2591_REGISTER_CHAN0_LOW = 0x14,      // Channel 0 data, low byte
  TSL2591_REGISTER_CHAN0_HIGH = 0x15,     // Channel 0 data, high byte
  TSL2591_REGISTER_CHAN1_LOW = 0x16,      // Channel 1 data, low byte
  TSL2591_REGISTER_CHAN1_HIGH = 0x17,     // Channel 1 data, high byte
};

/// Enumeration for the sensor integration timing
typedef enum {
  TSL2591_INTEGRATIONTIME_100MS = 0x00, // 100 millis
  TSL2591_INTEGRATIONTIME_200MS = 0x01, // 200 millis
  TSL2591_INTEGRATIONTIME_300MS = 0x02, // 300 millis
  TSL2591_INTEGRATIONTIME_400MS = 0x03, // 400 millis
  TSL2591_INTEGRATIONTIME_500MS = 0x04, // 500 millis
  TSL2591_INTEGRATIONTIME_600MS = 0x05, // 600 millis
} tsl2591IntegrationTime_t;

/// Enumeration for the persistance filter (for interrupts)
typedef enum {
  //  bit 7:4: 0
  TSL2591_PERSIST_EVERY = 0x00, // Every ALS cycle generates an interrupt
  TSL2591_PERSIST_ANY = 0x01,   // Any value outside of threshold range
  TSL2591_PERSIST_2 = 0x02,     // 2 consecutive values out of range
  TSL2591_PERSIST_3 = 0x03,     // 3 consecutive values out of range
  TSL2591_PERSIST_5 = 0x04,     // 5 consecutive values out of range
  TSL2591_PERSIST_10 = 0x05,    // 10 consecutive values out of range
  TSL2591_PERSIST_15 = 0x06,    // 15 consecutive values out of range
  TSL2591_PERSIST_20 = 0x07,    // 20 consecutive values out of range
  TSL2591_PERSIST_25 = 0x08,    // 25 consecutive values out of range
  TSL2591_PERSIST_30 = 0x09,    // 30 consecutive values out of range
  TSL2591_PERSIST_35 = 0x0A,    // 35 consecutive values out of range
  TSL2591_PERSIST_40 = 0x0B,    // 40 consecutive values out of range
  TSL2591_PERSIST_45 = 0x0C,    // 45 consecutive values out of range
  TSL2591_PERSIST_50 = 0x0D,    // 50 consecutive values out of range
  TSL2591_PERSIST_55 = 0x0E,    // 55 consecutive values out of range
  TSL2591_PERSIST_60 = 0x0F,    // 60 consecutive values out of range
} tsl2591Persist_t;

/// Enumeration for the sensor gain
typedef enum {
  TSL2591_GAIN_LOW = 0x00,  /// low gain (1x)
  TSL2591_GAIN_MED = 0x10,  /// medium gain (25x)
  TSL2591_GAIN_HIGH = 0x20, /// medium gain (428x)
  TSL2591_GAIN_MAX = 0x30,  /// max gain (9876x)
} tsl2591Gain_t;

typedef enum {
  TSL2591_FULLSPECTRUM,
  TSL2591_INFRARED,
  TSL2591_VISIBLE
} Channel;

tsl2591IntegrationTime_t _integration;
tsl2591Gain_t _gain;

// -----------------------------------------------------------------------------
// Prototypes
// -----------------------------------------------------------------------------
void Si7021Reset( TempertaureHumiditySensor sensor );
bool Si7021Begin( TempertaureHumiditySensor sensor );
uint8_t readTemperature( TempertaureHumiditySensor sensor );
uint8_t readHumidity( TempertaureHumiditySensor sensor );

void TSL2591Enable( LuminositySensor sensor );
void TSL2591Disable( LuminositySensor sensor );
bool TSL2591Begin( LuminositySensor sensor, tsl2591IntegrationTime_t integration, tsl2591Gain_t gain );
void TSL2591SetGainTiming( LuminositySensor sensor, tsl2591Gain_t gain, tsl2591IntegrationTime_t integration );
uint32_t TSL2591GetFullLuminosity( LuminositySensor sensor );
uint16_t readLuminosity( LuminositySensor sensor, Channel channel );

uint8_t readLightHeightCm( ProximitySensor sensor );
void controlLightHeight( Motor motor, Direction direction, uint8_t centimeters );

void controlRelay( Relay relay, State state );
void controlPanelRxData( void );

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

void Si7021Reset( TempertaureHumiditySensor sensor ) {
  switch( sensor ) {
    case TEMP_HUM_SENSOR_0:
      GPIO_PinClear( I2C_MUX_A0 );
      GPIO_PinClear( I2C_MUX_A1 );
      break;
    case TEMP_HUM_SENSOR_1:
      GPIO_PinClear( I2C_MUX_A0 );
      GPIO_PinSet( I2C_MUX_A1 );
      break;
  }
  uint8_t buffer[1] = { SI7021_RESET_CMD };
  I2C2_Write( SI7021_DEFAULT_ADDRESS, buffer, 1 );
  CORETIMER_DelayMs( 50 );
}

// -----------------------------------------------------------------------------

bool Si7021Begin( TempertaureHumiditySensor sensor ) {
  switch( sensor ) {
    case TEMP_HUM_SENSOR_0:
      GPIO_PinClear( I2C_MUX_A0 );
      GPIO_PinClear( I2C_MUX_A1 );
      break;
    case TEMP_HUM_SENSOR_1:
      GPIO_PinClear( I2C_MUX_A0 );
      GPIO_PinSet( I2C_MUX_A1 );
      break;
  }
  Si7021Reset( sensor );
  uint8_t buffer[1] = { SI7021_READRHT_REG_CMD };
  I2C2_WriteRead( SI7021_DEFAULT_ADDRESS, buffer, 1, buffer, 1 );
  if( buffer[0] != 0x3A ) {
    return false;
  }
  return true;
}

// -----------------------------------------------------------------------------

uint8_t readTemperature( TempertaureHumiditySensor sensor ) {
    // Select I2C mux channel
    switch( sensor ) {
        case TEMP_HUM_SENSOR_0:
            // Set I2C mux to channel 0
            GPIO_PinClear( I2C_MUX_A0 );
            GPIO_PinClear( I2C_MUX_A1 );
            break;
        case TEMP_HUM_SENSOR_1:
            // Set I2C mux to channel 1
            GPIO_PinClear( I2C_MUX_A0 );
            GPIO_PinSet( I2C_MUX_A1 );
            break;
    }

    // Begin temperature reading
    uint8_t buffer[3] = { SI7021_MEASTEMP_NOHOLD_CMD, 0, 0 };
    if( !I2C2_Write( SI7021_DEFAULT_ADDRESS, buffer, 1 ) ) {
      // Error
      return 0;
    }

    // Account for conversion time for reading temperature
    CORETIMER_DelayMs( 20 );

    // Wait for I2C bus to clear
    while( I2C2_IsBusy() );

    // Read current temperature from sensor
    if( I2C2_Read( SI7021_DEFAULT_ADDRESS, buffer, 3 ) ) {
      uint16_t temp = buffer[0] << 8 | buffer[1];

      // Convert to ^F
      float temperature = temp;
      temperature *= 175.72;
      temperature /= 65536;
      temperature -= 46.85;
      temperature *= 9;
      temperature /= 5;
      temperature += 32;
      return (uint8_t)temperature;
    }
    
    // 1/2 typical sample processing time
    CORETIMER_DelayMs( 6 );
    
    // Error
    return 0;
}

// -----------------------------------------------------------------------------

uint8_t readHumidity( TempertaureHumiditySensor sensor ) {
    // Select I2C mux channel
    switch( sensor ) {
        case TEMP_HUM_SENSOR_0:
            // Set I2C mux to channel 0
            GPIO_PinClear( I2C_MUX_A0 );
            GPIO_PinClear( I2C_MUX_A1 );
            break;
        case TEMP_HUM_SENSOR_1:
            // Set I2C mux to channel 1
            GPIO_PinClear( I2C_MUX_A0 );
            GPIO_PinSet( I2C_MUX_A1 );
            break;
    }

    // Begin humidity reading
    uint8_t buffer[3] = { SI7021_MEASRH_NOHOLD_CMD, 0, 0 };
    if( !I2C2_Write( SI7021_DEFAULT_ADDRESS, buffer, 1 ) ) {
      // Error
      return 0;
    }

    // Account for conversion time for reading humidity
    CORETIMER_DelayMs( 20 );

    // Wait for I2C bus to clear
    while( I2C2_IsBusy() );

    // Read current humidity from sensor
    if( I2C2_Read( SI7021_DEFAULT_ADDRESS, buffer, 3 ) ) {
      uint16_t hum = buffer[0] << 8 | buffer[1];

      float humidity = hum;
      humidity *= 125;
      humidity /= 65536;
      humidity -= 6;

      return (uint8_t) humidity > 100.0 ? 100.0 : humidity;
    }
    
    // 1/2 typical sample processing time
    CORETIMER_DelayMs( 6 );
    
    // Error
    return 0;
}


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

void TSL2591Enable( LuminositySensor sensor ) {
  uint8_t buffer[2] = { 
    TSL2591_COMMAND_BIT | TSL2591_REGISTER_ENABLE, 
    TSL2591_ENABLE_POWERON | TSL2591_ENABLE_AEN | TSL2591_ENABLE_AIEN | TSL2591_ENABLE_NPIEN 
  };
  
  // Select I2C mux channel
  switch( sensor ) {
    case LUM_SENSOR_0:
        // Set I2C mux to channel 0
        GPIO_PinClear( I2C_MUX_A0 );
        GPIO_PinClear( I2C_MUX_A1 );
        break;
    case LUM_SENSOR_1:
        // Set I2C mux to channel 1
        GPIO_PinClear( I2C_MUX_A0 );
        GPIO_PinSet( I2C_MUX_A1 );
        break;
  }

  I2C2_Write( TSL2591_ADDR, buffer, 2 );
}

// -----------------------------------------------------------------------------

void TSL2591Disable( LuminositySensor sensor ) {
  uint8_t buffer[2] = { TSL2591_COMMAND_BIT | TSL2591_REGISTER_ENABLE, TSL2591_ENABLE_POWEROFF };
  
  // Select I2C mux channel
  switch( sensor ) {
    case LUM_SENSOR_0:
        // Set I2C mux to channel 0
        GPIO_PinClear( I2C_MUX_A0 );
        GPIO_PinClear( I2C_MUX_A1 );
        break;
    case LUM_SENSOR_1:
        // Set I2C mux to channel 1
        GPIO_PinClear( I2C_MUX_A0 );
        GPIO_PinSet( I2C_MUX_A1 );
        break;
  }

  I2C2_Write( TSL2591_ADDR, buffer, 2 );
}

// -----------------------------------------------------------------------------

bool TSL2591Begin( LuminositySensor sensor, tsl2591IntegrationTime_t integration, tsl2591Gain_t gain ) {
  // Select I2C mux channel
  switch( sensor ) {
    case LUM_SENSOR_0:
        // Set I2C mux to channel 0
        GPIO_PinClear( I2C_MUX_A0 );
        GPIO_PinClear( I2C_MUX_A1 );
        break;
    case LUM_SENSOR_1:
        // Set I2C mux to channel 1
        GPIO_PinClear( I2C_MUX_A0 );
        GPIO_PinSet( I2C_MUX_A1 );
        break;
  }

  // Read device ID
  uint8_t buffer[1] = { TSL2591_COMMAND_BIT | TSL2591_REGISTER_DEVICE_ID };
  I2C2_WriteRead( TSL2591_ADDR, buffer, 1, buffer, 1 );

  // Confirm the device is connected
  if( buffer[0] != 0x50 ) {
    // Error
    return false;
  }
  TSL2591SetGainTiming( sensor, gain, integration );
  return true;
}

// -----------------------------------------------------------------------------

void TSL2591SetGainTiming( LuminositySensor sensor, tsl2591Gain_t gain, tsl2591IntegrationTime_t integration ) {
  TSL2591Enable( sensor );
  _gain = gain;
  _integration = integration;
  uint8_t buffer[2] = { TSL2591_COMMAND_BIT | TSL2591_REGISTER_CONTROL, _integration | _gain };
  I2C2_Write( TSL2591_ADDR, buffer, 2 );
  TSL2591Disable( sensor );
}

// -----------------------------------------------------------------------------

uint32_t TSL2591GetFullLuminosity( LuminositySensor sensor ) {
  // Enable the device
  TSL2591Enable( sensor );

  // Wait x ms for ADC to complete
  for (uint8_t d = 0; d <= _integration; d++) {
    CORETIMER_DelayMs( 120 );
  }

  // CHAN0 must be read before CHAN1
  uint32_t x;
  uint16_t y;
  uint8_t buffer[2] = { TSL2591_COMMAND_BIT | TSL2591_REGISTER_CHAN0_LOW, 0 };
  I2C2_WriteRead( TSL2591_ADDR, buffer, 1, buffer, 2 );
  y = (uint16_t)buffer[1] << 8 | (uint16_t)buffer[0];

  buffer[0] = TSL2591_COMMAND_BIT | TSL2591_REGISTER_CHAN1_LOW;
  I2C2_WriteRead( TSL2591_ADDR, buffer, 1, buffer, 2 );
  x = (uint16_t)buffer[1] << 8 | (uint16_t)buffer[0];

  x <<= 16;
  x |= y;

  TSL2591Disable( sensor );

  return x;
}

// -----------------------------------------------------------------------------

uint16_t readLuminosity( LuminositySensor sensor, Channel channel ) {
  uint32_t x = TSL2591GetFullLuminosity( sensor );

  switch( channel ) {
    case TSL2591_FULLSPECTRUM:
      // Reads two byte value from channel 0 (visible + infrared)
      return (x & 0xFFFF);
    case TSL2591_INFRARED:
      // Reads two byte value from channel 1 (infrared)
      return (x >> 16);
    case TSL2591_VISIBLE:
      // Reads all and subtracts out just the visible
      return ((x & 0xFFFF) - (x >> 16));
    default:
      return 0;
  }
}

// -----------------------------------------------------------------------------

/**
 * @def Read the distance in centimeters between a proximity sensor and the light.
 * @param sensorNumber:
 *      0 - Left proximity sensor
 *      1 - Right proximity sensor
 * @return Distance in centimeters
 */
uint8_t readLightHeightCm( ProximitySensor sensor ) {
    uint32_t startCount = 0;
    uint32_t endCount, timeUs;
    uint8_t centimeters;
    
    switch( sensor ) {
        // Left proximity sensor
        case PROXIMITY_SENSOR_LEFT:
            // Send start signal to the proximity sensor
            GPIO_PinClear( ULTRASONIC_CONTROL_0 );
            CORETIMER_DelayUs( 2 );
            GPIO_PinSet( ULTRASONIC_CONTROL_0 );
            CORETIMER_DelayUs( 10 );
            GPIO_PinClear( ULTRASONIC_CONTROL_0 );
            
            // Start time
            startCount = _CP0_GET_COUNT();
            
            // Wait for the returned signal
            while( !GPIO_PinRead( ULTRASONIC_ECHO_0 ) );
            break;
            
        // Right proximity sensor
        case PROXIMITY_SENSOR_RIGHT:
            // Send start signal to the proximity sensor
            GPIO_PinClear( ULTRASONIC_CONTROL_1 );
            CORETIMER_DelayUs( 2 );
            GPIO_PinSet( ULTRASONIC_CONTROL_1 );
            CORETIMER_DelayUs( 10 );
            GPIO_PinClear( ULTRASONIC_CONTROL_1 );
            
            // Start time
            startCount = _CP0_GET_COUNT();
            
            // Wait for the returned signal
            while( !GPIO_PinRead( ULTRASONIC_ECHO_1 ) );
            break;
    }
    // End time
    endCount = _CP0_GET_COUNT();

    // Calculate time in microseconds
    timeUs = ((endCount - startCount) * 1000000) / CORETIMER_FrequencyGet();
    
    // Calculate distance between light and sensor in centimeters
    centimeters = timeUs / 74 / 2;
    
    return centimeters;
}

// -----------------------------------------------------------------------------

void controlLightHeight( Motor motor, Direction direction, uint8_t centimeters ) {
    switch( motor ) {
        // Left motor
        case MOTOR_LEFT:
            // Raise lights
            if( direction == UP ) {
                // TODO: raise left motor desired number of centimeters
            }
            // Lower lights
            else {
                // TODO: lower left motor desired number of centimeters
            }
            break;
            
        // Right motor
        case MOTOR_RIGHT:
            // Raise lights
            if( direction == UP ) {
                // TODO: raise right motor desired number of centimeters
            }
            // Lower lights
            else {
                // TODO: lower right motor desired number of centimeters
            }
            break;
    }
}

// -----------------------------------------------------------------------------

void initRelays( void ) {
    GPIO_PinOutputEnable( HEATER );
    GPIO_PinOutputEnable( FAN_IN );
    GPIO_PinOutputEnable( FAN_OUT );
    GPIO_PinOutputEnable( HUMIDIFIER );
    GPIO_PinOutputEnable( LIGHTS );
    GPIO_PinOutputEnable( RELAY_5 );
    GPIO_PinOutputEnable( RELAY_6 );
    GPIO_PinOutputEnable( RELAY_7 );
}

// -----------------------------------------------------------------------------

void controlRelay( Relay relay, State state ) {
    // Turn relay on
    if( state ) {
        GPIO_PinSet( relay );
    }
    // Turn relay off
    else {
        GPIO_PinClear( relay );
    }
}

// -----------------------------------------------------------------------------

void controlPanelRxData( void ) {
    uint8_t lumUpper, lumLower;

    // Read desired conditions sent by the control panel
    desiredTemperature = I2C1_ReadByte();
    desiredHumidity = I2C1_ReadByte();
    lumUpper = I2C1_ReadByte();
    lumLower = I2C1_ReadByte();
    desiredLuminosity = ( lumUpper << 4 ) | lumLower;
    
    // Get current conditions of the enclosure
    uint8_t currentTemperature0 = readTemperature( TEMP_HUM_SENSOR_0 );
    uint8_t currentTemperature1 = readTemperature( TEMP_HUM_SENSOR_1 );
    uint8_t currentHumidity0 = readHumidity( TEMP_HUM_SENSOR_0 );
    uint8_t currentHumidity1 = readHumidity( TEMP_HUM_SENSOR_1 );
    uint16_t currentLuminosity0 = readLuminosity( LUM_SENSOR_0, TSL2591_FULLSPECTRUM );
    uint16_t currentLuminosity1 = readLuminosity( LUM_SENSOR_1, TSL2591_FULLSPECTRUM );
    
    // Send current conditions to control panel
    I2C1_WriteByte( currentTemperature0 );
    I2C1_WriteByte( currentTemperature1 );
    I2C1_WriteByte( currentHumidity0 );
    I2C1_WriteByte( currentHumidity1 );
    I2C1_WriteByte( currentLuminosity0 >> 4 );  // High byte
    I2C1_WriteByte( currentLuminosity0 );       // Low byte
    I2C1_WriteByte( currentLuminosity1 >> 4 );  // High byte
    I2C1_WriteByte( currentLuminosity1 );       // Low byte

    // End transmission
    // I2C1_LastByteAckStatusGet();
}

// -----------------------------------------------------------------------------

void climateControl( void ) {
  // Get current conditions of the enclosure
  uint8_t currentTemperature = readTemperature( TEMP_HUM_SENSOR_0 );
  uint8_t currentHumidity = readHumidity( TEMP_HUM_SENSOR_0 );
  uint16_t currentLuminosity = readLuminosity( LUM_SENSOR_0, TSL2591_FULLSPECTRUM );

  // ------------------------------- Temperature -------------------------------
  // Too cold
  if( currentTemperature < desiredTemperature * 0.98 ) {
    controlRelay( HEATER, ON );
    controlRelay( FAN_IN, ON );
  }
  // Too hot
  else if( currentTemperature > desiredTemperature * 1.02 ) {
    controlRelay( HEATER, OFF );
    controlRelay( FAN_IN, ON );
    controlRelay( FAN_OUT, ON );
  }
  // Just right
  else {
    controlRelay( HEATER, OFF );
    controlRelay( FAN_IN, OFF );
  }

  // -------------------------------- Humidity ---------------------------------
  // Too dry
  if( currentHumidity < desiredHumidity * 0.98 ) {
    controlRelay( HUMIDIFIER, ON );
    controlRelay( FAN_OUT, OFF );
  }
  // Too humid
  else if( currentHumidity > desiredHumidity * 1.02 ) {
    controlRelay( HUMIDIFIER, OFF );
    controlRelay( FAN_OUT, ON );
  }
  // Just right
  else {
    controlRelay( HUMIDIFIER, OFF );
    controlRelay( FAN_OUT, OFF );
  }

  // ------------------------------- Luminosity --------------------------------
  // No lights needed
  if( desiredLuminosity == 0 ) {
    controlRelay( LIGHTS, OFF );

    // Raise lights 1 cm at a time until lights are within 5 cm of the top of the enclosure
    while( readLightHeightCm( PROXIMITY_SENSOR_LEFT ) > 5 || readLightHeightCm( PROXIMITY_SENSOR_RIGHT ) > 5) {
      controlLightHeight( MOTOR_LEFT, UP, 1 );
      controlLightHeight( MOTOR_RIGHT, UP, 1 );
      CORETIMER_DelayMs( 100 );
    }
  }
  // Too dim
  else if( currentLuminosity < desiredLuminosity * 0.98 ) {
    controlRelay( LIGHTS, ON );

    // Lower lights 1 cm at a time until desired luminosity is met
    while( readLuminosity( LUM_SENSOR_0, TSL2591_FULLSPECTRUM ) < desiredLuminosity ) {
      controlLightHeight( MOTOR_LEFT, DOWN, 1 );
      controlLightHeight( MOTOR_RIGHT, DOWN, 1 );
    }
  }
  // Too bright
  else if( currentLuminosity > desiredLuminosity * 1.02 ) {
    controlRelay( LIGHTS, ON );

    // Raise lights 1 cm at a time until desired luminosity is met
    while( readLuminosity( LUM_SENSOR_0, TSL2591_FULLSPECTRUM ) > desiredLuminosity ) {
      controlLightHeight( MOTOR_LEFT, UP, 1 );
      controlLightHeight( MOTOR_RIGHT, UP, 1 );
    }
  }
}


// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );
    initRelays();
    
    U
//    controlRelay( HEATER, ON );
//    CORETIMER_DelayMs(1000);
//    controlRelay( HEATER, OFF );
//    
//
//    // Initialize temperature / humidity sensors
//    Si7021Begin( TEMP_HUM_SENSOR_0 );
//    Si7021Begin( TEMP_HUM_SENSOR_1 );
//
//    // Initialize luminosity sensors
//    TSL2591Begin( LUM_SENSOR_0, TSL2591_GAIN_MED, TSL2591_INTEGRATIONTIME_300MS );
//    TSL2591Begin( LUM_SENSOR_1, TSL2591_GAIN_MED, TSL2591_INTEGRATIONTIME_300MS );
//    
//    readHumidity( TEMP_HUM_SENSOR_0 );

    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );

//        climateControl();
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

